document.getElementById('clock').addEventListener('click', function(){
    const time = document.getElementById('time');
    if (time.classList.contains('hidden')){
        time.classList.remove('hidden')
        setTimeout(function() {
            time.classList.add('flex');
            time.classList.remove('opacity-0');
        }, 10);
    } else {
        time.classList.remove('flex');
        time.classList.add('opacity-0');
        setTimeout(function() {
            time.classList.add('hidden');
        }, 500); // Задержка равная длительности анимации
    }
});
