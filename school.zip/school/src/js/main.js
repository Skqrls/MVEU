let swiperCards = new Swiper('.swiper', {
    loop: true,
    slidesPerView: 2,
    pagination: {
      el: '.swiper-pagination',
    },
    navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev',
    },
  });
  const containers = document.querySelectorAll('.box');
  const addButtons = document.querySelectorAll('[id^="addButton"]');

  addButtons.forEach(button => {
      button.addEventListener('click', function(event) {
          const container = event.target.closest('.box ');
          if (container.classList.contains('active')) {
              container.classList.remove('active');
              button.textContent = '+';
          } else {
              containers.forEach(c => c.classList.remove('active'));
              addButtons.forEach(b => b.textContent = '+');
              container.classList.add('active');
              button.textContent = '-';
          }
      });
  });